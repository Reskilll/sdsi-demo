# PS5: Job Scheduler with Dependency Resolution (DAG)

A mini build / ETL orchestrator. Zero dependencies — JDK 21 only.

## Quick start

```
javac -d out src/com/sdsi/scheduler/*.java
java -cp out com.sdsi.scheduler.Main              # built-in demo
java -cp out com.sdsi.scheduler.Main --test       # test suite
java -cp out com.sdsi.scheduler.Main input.json   # your own DAG
```

Or on Windows: `build-and-run.bat`

## Input format

```json
{
  "jobs": [
    {"name": "A", "duration": 3, "dependsOn": []},
    {"name": "B", "duration": 5, "dependsOn": []},
    {"name": "C", "duration": 2, "dependsOn": ["A"]},
    {"name": "D", "duration": 4, "dependsOn": ["A", "B"]},
    {"name": "E", "duration": 1, "dependsOn": ["C", "D"]},
    {"name": "F", "duration": 3, "dependsOn": ["D"]}
  ],
  "workers": 2,
  "failJob": null
}
```

## Acceptance criteria

| Mark | Criterion | Implementation |
|------|-----------|----------------|
| M1 | Validate — cycles + missing deps | DFS tricolour cycle detection with full path; missing-dep scan |
| M2 | Topological sort | Kahn's algorithm (BFS with in-degree) |
| M3 | Parallel stages w/ worker limit N | Greedy list-scheduling; at most N jobs per stage |
| M4 | Critical path + min completion time | DP on topological order (earliest start/finish), then trace-back |
| M5 | Failure simulation | BFS on reverse adjacency from failed job; sorted output |

## Agent contract

```java
Map<String, Object> Agent.run(String task)
// Returns: { plan, result, escalated }
// result contains: valid, validationErrors, executionOrder, parallelStages,
//                  workerLimit, criticalPath, minCompletionTime,
//                  [failedJob, skippedJobs] (only when failJob is set)
```

## Architecture

```
com.sdsi.scheduler
├── Job.java        — immutable data class (name, duration, dependsOn)
├── JobGraph.java   — core DAG engine (all M1–M5 methods)
├── Json.java       — minimal recursive-descent JSON parser
├── Agent.java      — run(task) entry point
└── Main.java       — CLI driver + embedded test suite
```