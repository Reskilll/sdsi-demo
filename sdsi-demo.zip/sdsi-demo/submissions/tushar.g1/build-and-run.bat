@echo off
:: PS5: Job Scheduler with Dependency Resolution (DAG)
:: Compile + test + demo in one step.  Requires JDK 21+.

echo === Compiling ===
if not exist out mkdir out
javac -d out src\com\sdsi\scheduler\*.java
if %ERRORLEVEL% neq 0 exit /b %ERRORLEVEL%

echo.
echo === Running tests ===
java -cp out com.sdsi.scheduler.Main --test
if %ERRORLEVEL% neq 0 exit /b %ERRORLEVEL%

echo.
echo === Running demo ===
java -cp out com.sdsi.scheduler.Main