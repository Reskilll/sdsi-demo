package com.sdsi.scheduler;

import java.util.*;

/**
 * Top-level agent entry-point — matches the {@code run(task) → dict} contract
 * from the agent template.
 */
public class Agent {

    /**
     * Accepts a JSON string, runs the full pipeline (M1–M5 as requested), and
     * returns a result envelope.
     *
     * <pre>
     *   SchedulerResult = { plan: List&lt;String&gt;, result: Map&lt;String,Object&gt;, escalated: boolean }
     * </pre>
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> run(String task) {
        List<String> plan = new ArrayList<>();
        Map<String, Object> result = new LinkedHashMap<>();

        // --- parse ---
        Map<String, Object> input;
        try {
            input = (Map<String, Object>) Json.parse(task);
        } catch (Exception e) {
            return Map.of(
                "plan", List.of(),
                "result", Map.of("error", "Invalid JSON: " + e.getMessage()),
                "escalated", true);
        }

        List<Object> jobsRaw = (List<Object>) input.get("jobs");
        if (jobsRaw == null || jobsRaw.isEmpty()) {
            return Map.of(
                "plan", List.of(),
                "result", Map.of("error", "No jobs provided."),
                "escalated", true);
        }

        List<Job> jobList = new ArrayList<>();
        for (Object jr : jobsRaw) {
            Map<String, Object> jm = (Map<String, Object>) jr;
            jobList.add(new Job(
                Json.str(jm, "name"),
                Json.integer(jm, "duration"),
                Json.stringList(jm, "dependsOn")));
        }

        JobGraph graph = new JobGraph(jobList);

        // ---- M1: Validate ----
        plan.add("M1: validate graph");
        List<String> errors = graph.validate();
        result.put("validationErrors", errors);
        if (!errors.isEmpty()) {
            result.put("valid", false);
            return Map.of("plan", plan, "result", result, "escalated", false);
        }
        result.put("valid", true);

        // ---- M2: Topological sort ----
        plan.add("M2: topological sort");
        result.put("executionOrder", graph.topologicalSort());

        // ---- M3: Parallel stages ----
        plan.add("M3: parallel stages");
        int workers = Math.max(1, Json.integer(input, "workers"));
        result.put("parallelStages", graph.parallelSchedule(workers));
        result.put("workerLimit", workers);

        // ---- M4: Critical path ----
        plan.add("M4: critical path");
        var cp = graph.criticalPath();
        result.put("criticalPath", cp.path());
        result.put("minCompletionTime", cp.totalTime());

        // ---- M5: Failure simulation (only when failJob is set) ----
        String failJob = Json.str(input, "failJob");
        if (failJob != null && !failJob.isBlank()) {
            plan.add("M5: simulate failure");
            result.put("failedJob", failJob);
            result.put("skippedJobs", graph.downstreamJobs(failJob));
        }

        return Map.of("plan", plan, "result", result, "escalated", false);
    }
}