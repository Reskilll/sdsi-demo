package com.sdsi.scheduler;

import java.util.*;

/**
 * A single job in the DAG — name, duration, and list of upstream dependencies.
 */
public class Job {
    public final String name;
    public final int duration;
    public final List<String> dependsOn;

    public Job(String name, int duration, List<String> dependsOn) {
        this.name = name;
        this.duration = duration;
        this.dependsOn = dependsOn != null ? List.copyOf(dependsOn) : List.of();
    }

    @Override
    public String toString() {
        return String.format("%s(d=%d → %s)", name, duration, dependsOn);
    }
}