package com.sdsi.scheduler;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Directed acyclic graph of jobs.  All five acceptance criteria are implemented
 * as public methods.
 *
 * <ul>
 *   <li>M1 — validate(): detect cycles and missing dependencies</li>
 *   <li>M2 — topologicalSort()</li>
 *   <li>M3 — parallelSchedule(workers)</li>
 *   <li>M4 — criticalPath()</li>
 *   <li>M5 — downstreamJobs(failedJob)</li>
 * </ul>
 */
public class JobGraph {

    private final Map<String, Job> jobs;
    private final Map<String, List<String>> successors; // reverse adjacency

    public JobGraph(List<Job> jobList) {
        this.jobs = new LinkedHashMap<>();
        for (Job j : jobList) {
            this.jobs.put(j.name, j);
        }
        // Build reverse adjacency once
        this.successors = new HashMap<>();
        for (String name : jobs.keySet()) {
            successors.put(name, new ArrayList<>());
        }
        for (Job j : jobs.values()) {
            for (String dep : j.dependsOn) {
                if (jobs.containsKey(dep)) {
                    successors.computeIfAbsent(dep, k -> new ArrayList<>()).add(j.name);
                }
            }
        }
    }

    // ========================================================================
    //  M1 — Validation  (cycles + missing deps)
    // ========================================================================

    /**
     * Returns a list of human-readable error strings.  Empty → graph is clean.
     */
    public List<String> validate() {
        List<String> errors = new ArrayList<>();

        // --- missing dependencies ---
        for (Job job : jobs.values()) {
            for (String dep : job.dependsOn) {
                if (!jobs.containsKey(dep)) {
                    errors.add(String.format(
                        "MISSING-DEP: job '%s' depends on '%s' but '%s' is not defined.",
                        job.name, dep, dep));
                }
            }
        }

        // --- cycle detection (DFS tricolour) ---
        final int WHITE = 0, GRAY = 1, BLACK = 2;
        Map<String, Integer> colour = new HashMap<>();
        for (String name : jobs.keySet()) {
            colour.put(name, WHITE);
        }

        List<String> cycleResult = new ArrayList<>();
        for (String name : jobs.keySet()) {
            if (colour.get(name) == WHITE) {
                List<String> stack = new ArrayList<>();
                dfsCycle(name, colour, stack, cycleResult);
                if (!cycleResult.isEmpty()) break;
            }
        }

        if (!cycleResult.isEmpty()) {
            errors.add("CYCLE: " + String.join(" → ", cycleResult));
        }

        return errors;
    }

    private void dfsCycle(String u, Map<String, Integer> colour,
                          List<String> stack, List<String> cycleResult) {
        if (!colour.containsKey(u)) return; // missing dep – reported elsewhere
        colour.put(u, 1); // GRAY
        stack.add(u);
        Job job = jobs.get(u);
        if (job != null) {
            for (String v : job.dependsOn) {
                if (!colour.containsKey(v)) continue;
                if (colour.get(v) == 1 && cycleResult.isEmpty()) {
                    // Found back-edge → extract cycle
                    int idx = stack.indexOf(v);
                    cycleResult.addAll(stack.subList(idx, stack.size()));
                    cycleResult.add(v);
                    return;
                }
                if (colour.get(v) == 0) {
                    dfsCycle(v, colour, stack, cycleResult);
                    if (!cycleResult.isEmpty()) return;
                }
            }
        }
        stack.remove(stack.size() - 1);
        colour.put(u, 2); // BLACK
    }

    // ========================================================================
    //  M2 — Topological sort  (Kahn's algorithm)
    // ========================================================================

    public List<String> topologicalSort() {
        Map<String, Integer> inDegree = new LinkedHashMap<>();
        for (String name : jobs.keySet()) {
            inDegree.put(name, 0);
        }
        for (Job job : jobs.values()) {
            for (String dep : job.dependsOn) {
                if (inDegree.containsKey(dep)) {
                    inDegree.merge(job.name, 1, Integer::sum);
                }
            }
        }

        Deque<String> q = new ArrayDeque<>();
        for (var e : inDegree.entrySet()) {
            if (e.getValue() == 0) q.add(e.getKey());
        }

        List<String> order = new ArrayList<>();
        while (!q.isEmpty()) {
            String u = q.poll();
            order.add(u);
            for (String succ : successors.getOrDefault(u, List.of())) {
                inDegree.merge(succ, -1, (old, delta) -> old + delta);
                if (inDegree.get(succ) == 0) {
                    q.add(succ);
                }
            }
        }

        if (order.size() != jobs.size()) {
            throw new IllegalStateException(
                "Graph contains a cycle; topological sort impossible.");
        }
        return order;
    }

    // ========================================================================
    //  M3 — Parallel stages with bounded worker pool
    // ========================================================================

    /**
     * Greedy list-scheduling: at most {@code workers} jobs per stage.
     */
    public List<List<String>> parallelSchedule(int workers) {
        Map<String, Integer> inDegree = new LinkedHashMap<>();
        for (String name : jobs.keySet()) {
            inDegree.put(name, jobs.get(name).dependsOn.size());
        }

        List<String> ready = new ArrayList<>();
        for (var e : inDegree.entrySet()) {
            if (e.getValue() == 0) ready.add(e.getKey());
        }

        List<List<String>> stages = new ArrayList<>();

        while (!ready.isEmpty()) {
            // Take up to 'workers' jobs for this stage
            List<String> stage = new ArrayList<>();
            int taken = Math.min(workers, ready.size());
            for (int i = 0; i < taken; i++) {
                stage.add(ready.get(i));
            }
            stages.add(stage);

            // Remove scheduled jobs from ready list
            List<String> remaining = new ArrayList<>(ready.subList(taken, ready.size()));

            // Enqueue newly-ready successors
            for (String jobName : stage) {
                for (String succ : successors.getOrDefault(jobName, List.of())) {
                    inDegree.merge(succ, -1, Integer::sum);
                    if (inDegree.get(succ) == 0) {
                        remaining.add(succ);
                    }
                }
            }
            ready = remaining;
        }

        return stages;
    }

    // ========================================================================
    //  M4 — Critical path & min completion time
    // ========================================================================

    /**
     * Returns a record-like container holding the critical-path job names and
     * the minimum total completion time.
     */
    public CriticalPathResult criticalPath() {
        List<String> order = topologicalSort();

        Map<String, Integer> est = new LinkedHashMap<>(); // earliest start
        Map<String, Integer> eft = new LinkedHashMap<>(); // earliest finish

        for (String name : order) {
            Job job = jobs.get(name);
            int start = 0;
            for (String dep : job.dependsOn) {
                if (eft.containsKey(dep)) {
                    start = Math.max(start, eft.get(dep));
                }
            }
            est.put(name, start);
            eft.put(name, start + job.duration);
        }

        int totalTime = eft.values().stream().max(Integer::compareTo).orElse(0);

        // Trace back
        LinkedList<String> path = new LinkedList<>();
        String current = null;
        for (int i = order.size() - 1; i >= 0; i--) {
            if (eft.get(order.get(i)) == totalTime) {
                current = order.get(i);
                break;
            }
        }

        while (current != null) {
            path.addFirst(current);
            Job job = jobs.get(current);
            String pred = null;
            for (String dep : job.dependsOn) {
                if (eft.containsKey(dep) && eft.get(dep).equals(est.get(current))) {
                    pred = dep;
                    break;
                }
            }
            current = pred;
        }

        return new CriticalPathResult(path, totalTime);
    }

    /** Lightweight result holder for M4. */
    public record CriticalPathResult(List<String> path, int totalTime) {}

    // ========================================================================
    //  M5 — Failure simulation
    // ========================================================================

    /**
     * Returns every job (transitive) that depends on {@code failedJob}, sorted
     * alphabetically for determinism.  These are the jobs that would be skipped.
     */
    public List<String> downstreamJobs(String failedJob) {
        if (!jobs.containsKey(failedJob)) {
            return List.of();
        }

        Set<String> visited = new LinkedHashSet<>();
        Deque<String> stack = new ArrayDeque<>();
        stack.push(failedJob);

        while (!stack.isEmpty()) {
            String u = stack.pop();
            for (String v : successors.getOrDefault(u, List.of())) {
                if (visited.add(v)) {
                    stack.push(v);
                }
            }
        }

        return visited.stream().sorted().collect(Collectors.toList());
    }

    // ========================================================================
    //  Helpers
    // ========================================================================

    public Map<String, Job> getJobs() { return Collections.unmodifiableMap(jobs); }
}