package com.sdsi.scheduler;

import java.util.*;

/**
 * Minimal recursive-descent JSON parser.  Handles strings, integers, arrays,
 * and objects deep enough for the problem's input schema — zero dependencies.
 *
 * <p>Used solely so the project compiles and runs with {@code javac} + JDK 21.
 */
public class Json {

    private final String src;
    private int pos;

    private Json(String src) {
        this.src = src;
        this.pos = 0;
    }

    /** Parse the root JSON value. */
    public static Object parse(String src) {
        Json p = new Json(src);
        Object val = p.parseValue();
        p.skipWhitespace();
        if (p.pos != p.src.length()) {
            throw new IllegalArgumentException("Unexpected trailing content at pos " + p.pos);
        }
        return val;
    }

    // --- internals ---

    private char peek() { return pos < src.length() ? src.charAt(pos) : '\0'; }
    private char advance() { return src.charAt(pos++); }

    private void skipWhitespace() {
        while (pos < src.length() && Character.isWhitespace(src.charAt(pos))) pos++;
    }

    private void expect(char c) {
        skipWhitespace();
        if (pos >= src.length() || src.charAt(pos) != c)
            throw new IllegalArgumentException("Expected '" + c + "' at pos " + pos);
        pos++;
    }

    private Object parseValue() {
        skipWhitespace();
        if (pos >= src.length()) throw new IllegalArgumentException("Unexpected EOF");
        char c = peek();
        return switch (c) {
            case '"' -> parseString();
            case '{' -> parseObject();
            case '[' -> parseArray();
            case 't', 'f' -> parseBoolean();
            case 'n' -> parseNull();
            default -> {
                if (c == '-' || Character.isDigit(c)) yield parseNumber();
                throw new IllegalArgumentException("Unexpected char '" + c + "' at pos " + pos);
            }
        };
    }

    private String parseString() {
        expect('"');
        StringBuilder sb = new StringBuilder();
        while (pos < src.length()) {
            char c = advance();
            if (c == '"') return sb.toString();
            if (c == '\\') {
                if (pos >= src.length()) throw new IllegalArgumentException("Unterminated escape");
                char esc = advance();
                switch (esc) {
                    case '"', '\\', '/' -> sb.append(esc);
                    case 'n' -> sb.append('\n');
                    case 't' -> sb.append('\t');
                    case 'r' -> sb.append('\r');
                    case 'u' -> {
                        if (pos + 4 > src.length()) throw new IllegalArgumentException("Bad unicode escape");
                        String hex = src.substring(pos, pos + 4);
                        sb.append((char) Integer.parseInt(hex, 16));
                        pos += 4;
                    }
                    default -> throw new IllegalArgumentException("Unknown escape \\" + esc);
                }
            } else {
                sb.append(c);
            }
        }
        throw new IllegalArgumentException("Unterminated string");
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseObject() {
        expect('{');
        Map<String, Object> map = new LinkedHashMap<>();
        skipWhitespace();
        if (peek() == '}') { pos++; return map; }
        while (true) {
            skipWhitespace();
            String key = parseString();
            expect(':');
            Object val = parseValue();
            map.put(key, val);
            skipWhitespace();
            if (peek() == '}') { pos++; return map; }
            expect(',');
        }
    }

    private List<Object> parseArray() {
        expect('[');
        List<Object> list = new ArrayList<>();
        skipWhitespace();
        if (peek() == ']') { pos++; return list; }
        while (true) {
            list.add(parseValue());
            skipWhitespace();
            if (peek() == ']') { pos++; return list; }
            expect(',');
        }
    }

    private Boolean parseBoolean() {
        if (src.startsWith("true", pos)) { pos += 4; return true; }
        if (src.startsWith("false", pos)) { pos += 5; return false; }
        throw new IllegalArgumentException("Bad boolean at " + pos);
    }

    private Object parseNull() {
        if (src.startsWith("null", pos)) { pos += 4; return null; }
        throw new IllegalArgumentException("Bad null at " + pos);
    }

    private Number parseNumber() {
        int start = pos;
        if (peek() == '-') pos++;
        while (pos < src.length() && Character.isDigit(peek())) pos++;
        if (pos < src.length() && peek() == '.') {
            pos++;
            while (pos < src.length() && Character.isDigit(peek())) pos++;
            return Double.parseDouble(src.substring(start, pos));
        }
        return Integer.parseInt(src.substring(start, pos));
    }

    // --- convenience helpers ---

    @SuppressWarnings("unchecked")
    public static String str(Map<String, Object> m, String key) {
        Object v = m.get(key);
        return v != null ? v.toString() : null;
    }

    @SuppressWarnings("unchecked")
    public static int integer(Map<String, Object> m, String key) {
        Object v = m.get(key);
        if (v instanceof Number n) return n.intValue();
        return Integer.parseInt(v.toString());
    }

    @SuppressWarnings("unchecked")
    public static List<String> stringList(Map<String, Object> m, String key) {
        Object v = m.get(key);
        if (v == null) return List.of();
        List<String> out = new ArrayList<>();
        for (Object item : (List<Object>) v) out.add(item.toString());
        return out;
    }
}