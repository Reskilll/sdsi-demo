package com.sdsi.scheduler;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.BooleanSupplier;

/**
 * CLI entry-point.  Three modes:
 *
 * <pre>
 *   java Main                  runs built-in demo
 *   java Main input.json       reads JSON from file
 *   java Main --test           runs the test suite
 * </pre>
 */
public class Main {

    private static final String SAMPLE_JSON = """
        {
          "jobs": [
            {"name": "A", "duration": 3, "dependsOn": []},
            {"name": "B", "duration": 5, "dependsOn": []},
            {"name": "C", "duration": 2, "dependsOn": ["A"]},
            {"name": "D", "duration": 4, "dependsOn": ["A", "B"]},
            {"name": "E", "duration": 1, "dependsOn": ["C", "D"]},
            {"name": "F", "duration": 3, "dependsOn": ["D"]}
          ],
          "workers": 2,
          "failJob": null
        }""";

    // ====================================================================
    //  MAIN
    // ====================================================================

    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws IOException {
        if (args.length >= 1 && args[0].equals("--test")) {
            runTests();
            return;
        }

        String json;
        if (args.length >= 1) {
            json = Files.readString(Path.of(args[0]));
        } else {
            json = SAMPLE_JSON;
            System.out.println("Using built-in sample.  Pass a file path to use your own.\n");
        }

        Map<String, Object> output = Agent.run(json);
        printReport(output);

        // M5 extra demo
        if (args.length == 0) {
            System.out.println();
            System.out.println(sep("FAILURE SIMULATION (M5) — extra demo"));
            String failJson = SAMPLE_JSON.replace("\"failJob\": null", "\"failJob\": \"D\"");
            Map<String, Object> failOut = Agent.run(failJson);
            Map<String, Object> fr = (Map<String, Object>) failOut.get("result");
            System.out.printf("  If job '%s' fails, skipped downstream: %s%n",
                fr.get("failedJob"), fr.get("skippedJobs"));
        }
    }

    @SuppressWarnings("unchecked")
    private static void printReport(Map<String, Object> output) {
        Map<String, Object> r = (Map<String, Object>) output.get("result");

        System.out.println(sep("VALIDATION (M1)"));
        if (Boolean.TRUE.equals(r.get("valid"))) {
            System.out.println("✓ Graph is valid — no cycles, no missing dependencies.");
        } else {
            for (String err : (List<String>) r.getOrDefault("validationErrors", List.of())) {
                System.out.println("✗ " + err);
            }
            return;
        }

        System.out.println(sep("EXECUTION ORDER  (M2)"));
        List<String> order = (List<String>) r.get("executionOrder");
        System.out.println("  " + String.join(" → ", order));

        System.out.println(sep("PARALLEL STAGES  (M3)  —  " + r.get("workerLimit") + " workers"));
        List<List<String>> stages = (List<List<String>>) r.get("parallelStages");
        int sn = 1;
        for (List<String> stage : stages) {
            System.out.printf("  Stage %d: %s%n", sn++, stage);
        }

        System.out.println(sep("CRITICAL PATH  (M4)"));
        List<String> cp = (List<String>) r.get("criticalPath");
        System.out.println("  Path: " + String.join(" → ", cp));
        System.out.println("  Min completion time: " + r.get("minCompletionTime"));
    }

    // ====================================================================
    //  TEST SUITE
    // ====================================================================

    private static int passed, failed;
    private static String currentTest;

    private static void runTests() {
        passed = 0; failed = 0;

        // ---- M1 ----
        test("M1: clean graph passes", () -> canonical().validate().isEmpty());

        test("M1: missing dep reported", () -> {
            JobGraph g = new JobGraph(List.of(new Job("A", 2, List.of("Z"))));
            List<String> errs = g.validate();
            return errs.size() == 1 && errs.get(0).contains("MISSING-DEP") && errs.get(0).contains("Z");
        });

        test("M1: simple cycle", () -> {
            JobGraph g = new JobGraph(List.of(
                new Job("A", 1, List.of("B")),
                new Job("B", 1, List.of("A"))));
            List<String> errs = g.validate();
            return errs.size() == 1 && errs.get(0).contains("CYCLE") && errs.get(0).contains("A") && errs.get(0).contains("B");
        });

        test("M1: 3-node cycle path", () -> {
            JobGraph g = new JobGraph(List.of(
                new Job("X", 1, List.of("Y")),
                new Job("Y", 1, List.of("Z")),
                new Job("Z", 1, List.of("X"))));
            List<String> errs = g.validate();
            return errs.size() == 1 && errs.get(0).equals("CYCLE: X → Y → Z → X");
        });

        test("M1: cycle + missing dep together", () -> {
            JobGraph g = new JobGraph(List.of(
                new Job("A", 1, List.of("B")),
                new Job("B", 1, List.of("A", "GHOST"))));
            List<String> errs = g.validate();
            return errs.size() == 2;
        });

        // ---- M2 ----
        test("M2: topological order", () -> {
            List<String> order = canonical().topologicalSort();
            return order.size() == 6
                && order.indexOf("A") < order.indexOf("C")
                && order.indexOf("A") < order.indexOf("D")
                && order.indexOf("B") < order.indexOf("D")
                && order.indexOf("C") < order.indexOf("E")
                && order.indexOf("D") < order.indexOf("E")
                && order.indexOf("D") < order.indexOf("F");
        });

        test("M2: throws on cycle", () -> {
            JobGraph g = new JobGraph(List.of(
                new Job("A", 1, List.of("B")),
                new Job("B", 1, List.of("A"))));
            try { g.topologicalSort(); return false; }
            catch (IllegalStateException e) { return true; }
        });

        test("M2: single node", () -> {
            JobGraph g = new JobGraph(List.of(new Job("Only", 5, List.of())));
            return g.topologicalSort().equals(List.of("Only"));
        });

        // ---- M3 ----
        test("M3: respects worker limit", () -> {
            for (int w = 1; w <= 4; w++) {
                for (var stage : canonical().parallelSchedule(w)) {
                    if (stage.size() > w) return false;
                }
            }
            return true;
        });

        test("M3: respects dependency order", () -> {
            var stages = canonical().parallelSchedule(2);
            Map<String, Integer> pos = new LinkedHashMap<>();
            int p = 0;
            for (var stage : stages) for (String name : stage) pos.put(name, p++);
            return pos.get("A") < pos.get("C")
                && pos.get("A") < pos.get("D")
                && pos.get("B") < pos.get("D")
                && pos.get("C") < pos.get("E")
                && pos.get("D") < pos.get("E")
                && pos.get("D") < pos.get("F");
        });

        test("M3: 1 worker ⇒ sequential", () -> {
            var stages = canonical().parallelSchedule(1);
            return stages.size() == 6 && stages.stream().allMatch(s -> s.size() == 1);
        });

        // ---- M4 ----
        test("M4: critical path", () -> {
            // B(5)→D(4)→F(3)=12 is the longest path through the DAG
            var cp = canonical().criticalPath();
            return cp.totalTime() == 12 && cp.path().equals(List.of("B", "D", "F"));
        });

        test("M4: single job", () -> {
            JobGraph g = new JobGraph(List.of(new Job("X", 7, List.of())));
            var cp = g.criticalPath();
            return cp.totalTime() == 7 && cp.path().equals(List.of("X"));
        });

        // ---- M5 ----
        test("M5: downstream from middle", () -> {
            return canonical().downstreamJobs("D").equals(List.of("E", "F"));
        });

        test("M5: downstream from leaf ⇒ empty", () -> {
            return canonical().downstreamJobs("E").isEmpty();
        });

        test("M5: downstream from root", () -> {
            return canonical().downstreamJobs("A").equals(List.of("C", "D", "E", "F"));
        });

        test("M5: unknown job ⇒ empty", () -> {
            return canonical().downstreamJobs("NOSUCHJOB").isEmpty();
        });

        // ---- Integration ----
        test("Integration: full Agent.run", () -> {
            @SuppressWarnings("unchecked")
            Map<String, Object> out = Agent.run(SAMPLE_JSON);
            Map<String, Object> r = (Map<String, Object>) out.get("result");
            return Boolean.TRUE.equals(r.get("valid"))
                && r.get("criticalPath").equals(List.of("B", "D", "F"))
                && r.get("minCompletionTime").equals(12)
                && r.get("executionOrder").equals(List.of("A", "B", "C", "D", "E", "F"));
        });

        test("Integration: cycle is invalid", () -> {
            String json = """
                {"jobs":[{"name":"A","duration":1,"dependsOn":["B"]},
                         {"name":"B","duration":1,"dependsOn":["A"]}],"workers":1}""";
            @SuppressWarnings("unchecked")
            Map<String, Object> out = Agent.run(json);
            Map<String, Object> r = (Map<String, Object>) out.get("result");
            return Boolean.FALSE.equals(r.get("valid"));
        });

        test("Integration: invalid JSON escalates", () -> {
            Map<String, Object> out = Agent.run("not json");
            return Boolean.TRUE.equals(out.get("escalated"));
        });

        // ---- Summary ----
        int total = passed + failed;
        System.out.printf("%n%s%n  %d/%d passed%s%n",
            failed == 0 ? "✓ ALL TESTS PASSED" : "✗ SOME TESTS FAILED",
            passed, total, failed > 0 ? "  (" + failed + " failed)" : "");
        if (failed > 0) System.exit(1);
    }

    private static JobGraph canonical() {
        return new JobGraph(List.of(
            new Job("A", 3, List.of()),
            new Job("B", 5, List.of()),
            new Job("C", 2, List.of("A")),
            new Job("D", 4, List.of("A", "B")),
            new Job("E", 1, List.of("C", "D")),
            new Job("F", 3, List.of("D"))
        ));
    }

    private static void test(String name, BooleanSupplier fn) {
        currentTest = name;
        try {
            if (fn.getAsBoolean()) {
                passed++;
                System.out.println("  ✓ " + name);
            } else {
                failed++;
                System.out.println("  ✗ " + name + "  (assertion returned false)");
            }
        } catch (Exception e) {
            failed++;
            System.out.println("  ✗ " + name + "  (threw: " + e + ")");
        }
    }

    // ====================================================================
    //  Utility
    // ====================================================================

    private static String sep(String title) {
        return "\n" + "─".repeat(60) + "\n  " + title + "\n" + "─".repeat(60);
    }
}